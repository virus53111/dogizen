@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap.ps1" -Action server
if errorlevel 1 (
  echo.
  echo A problem occurred. Please read README-RU.txt.
  pause
)
endlocal
