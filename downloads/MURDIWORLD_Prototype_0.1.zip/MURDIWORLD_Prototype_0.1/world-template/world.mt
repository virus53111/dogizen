gameid = mineclone2
backend = sqlite3
player_backend = sqlite3
auth_backend = sqlite3
