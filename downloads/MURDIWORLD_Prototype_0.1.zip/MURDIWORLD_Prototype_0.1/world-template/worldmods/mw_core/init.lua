-- MURDIWORLD Crystal Adventure 0.1
-- Original game-specific mod (MIT). Built for Luanti + VoxeLibre.
-- No network calls, file access, purchases or third-party tracking.

local storage = core.get_mod_storage()
local huds = {}
local QUEST_TARGET = 5

local function escape(value)
    return core.formspec_escape(tostring(value))
end

local function find_spawn()
    return core.string_to_pos(storage:get_string("spawn"))
end

local function remember_spawn(pos)
    if storage:get_string("spawn") == "" then
        storage:set_string("spawn", core.pos_to_string(pos))
        core.log("action", "[mw_core] Saved original arrival point")
    end
end

local function score(player)
    return player:get_meta():get_int("mw_crystals")
end

local function quest_text(player)
    local count = score(player)
    if count >= QUEST_TARGET then
        return "MURDIWORLD  |  Crystal explorer: " .. count .. "  [QUEST COMPLETE]"
    end
    return "MURDIWORLD  |  Find crystals: " .. count .. "/" .. QUEST_TARGET
end

local function update_hud(player)
    local name = player:get_player_name()
    if not huds[name] then
        huds[name] = player:hud_add({
            hud_elem_type = "text",
            position = {x = 0.02, y = 0.12},
            offset = {x = 0, y = 0},
            text = quest_text(player),
            alignment = {x = 1, y = 0},
            number = 0x7be9ff,
            scale = {x = 100, y = 20},
        })
    else
        player:hud_change(huds[name], "text", quest_text(player))
    end
end

local function show_guide(player)
    local name = player:get_player_name()
    local crystals = score(player)
    local done = crystals >= QUEST_TARGET
    local line = done and "Quest complete! Your crystal beacon has been awarded."
        or ("Mine " .. (QUEST_TARGET - crystals) .. " glowing ore blocks underground to earn a beacon.")
    local parts = {
        "formspec_version[4]",
        "size[11,8]",
        "bgcolor[#0a1530;true]",
        "label[0.6,0.65;MURDIWORLD  /  CRYSTAL ADVENTURE]",
        "label[0.6,1.45;A shared survival world. Explore, mine, build and discover.]",
        "label[0.6,2.05;" .. escape(line) .. "]",
        "label[0.6,2.65;Crystals mined: " .. crystals .. "]",
        "label[0.6,3.25;WASD - move  |  Space - jump  |  Left click - mine  |  Right click - place]",
        "label[0.6,3.85;Use /mwsethome to save a place, /mwhome to return, /mwhub for first spawn.]",
        "button[0.7,4.65;3.0,0.9;sethome;SET HOME]",
        "button[4.0,4.65;3.0,0.9;home;GO HOME]",
        "button[7.3,4.65;3.0,0.9;hub;GO TO HUB]",
        "label[0.6,6.1;World progress saves automatically when the game/server runs.]",
        "button_exit[7.8,6.85;2.5,0.7;close;PLAY]",
    }
    core.show_formspec(name, "mw_core:guide", table.concat(parts))
end

local function set_home(player)
    player:get_meta():set_string("mw_home", core.pos_to_string(player:get_pos()))
    core.chat_send_player(player:get_player_name(), "[MURDIWORLD] Home saved. Use /mwhome to return.")
    return true, "Home saved"
end

local function teleport_to(player, stored)
    if not stored then
        core.chat_send_player(player:get_player_name(), "[MURDIWORLD] No destination saved yet.")
        return false, "No destination saved yet"
    end
    player:set_pos(stored)
    return true, "Teleported"
end

local function get_player(name)
    return core.get_player_by_name(name)
end

core.register_craftitem("mw_core:guide", {
    description = "MURDIWORLD Field Guide (right-click to open)",
    inventory_image = "mw_guide.png",
    stack_max = 1,
    on_use = function(_, user)
        if user and user:is_player() then show_guide(user) end
        return nil
    end,
    on_secondary_use = function(_, user)
        if user and user:is_player() then show_guide(user) end
        return nil
    end,
})

core.register_craftitem("mw_core:shard", {
    description = "Azure Crystal Shard",
    inventory_image = "mw_shard.png",
    groups = {craftitem = 1},
})

core.register_node("mw_core:crystal_ore", {
    description = "Azure Crystal Ore (MURDIWORLD quest)",
    tiles = {"mw_crystal_ore.png"},
    groups = {cracky = 2, pickaxey = 2, building_block = 1},
    _mcl_hardness = 2,
    _mcl_blast_resistance = 6,
    drop = "mw_core:shard",
    is_ground_content = true,
    light_source = 4,
})

core.register_node("mw_core:beacon", {
    description = "Crystal Beacon (MURDIWORLD quest reward)",
    tiles = {"mw_beacon.png"},
    groups = {cracky = 2, pickaxey = 2, building_block = 1},
    _mcl_hardness = 2,
    light_source = 12,
    is_ground_content = false,
})

core.register_ore({
    ore_type = "scatter",
    ore = "mw_core:crystal_ore",
    wherein = {"mcl_core:stone", "mcl_deepslate:deepslate"},
    clust_scarcity = 12 * 12 * 12,
    clust_num_ores = 4,
    clust_size = 3,
    y_min = -350,
    y_max = -8,
})

core.register_on_dignode(function(_, oldnode, digger)
    if oldnode.name ~= "mw_core:crystal_ore" or not digger or not digger:is_player() then
        return
    end
    local meta = digger:get_meta()
    local count = meta:get_int("mw_crystals") + 1
    meta:set_int("mw_crystals", count)
    update_hud(digger)
    local name = digger:get_player_name()
    if count == QUEST_TARGET then
        digger:get_inventory():add_item("main", "mw_core:beacon")
        core.chat_send_player(name, "[MURDIWORLD] QUEST COMPLETE! You earned a glowing Crystal Beacon!")
    elseif count < QUEST_TARGET then
        core.chat_send_player(name, "[MURDIWORLD] Azure crystal " .. count .. "/" .. QUEST_TARGET)
    else
        core.chat_send_player(name, "[MURDIWORLD] Total crystals collected: " .. count)
    end
end)

core.register_on_newplayer(function(player)
    core.after(2, function()
        local live = core.get_player_by_name(player:get_player_name())
        if not live then return end
        remember_spawn(live:get_pos())
        show_guide(live)
    end)
end)

core.register_on_joinplayer(function(player)
    local name = player:get_player_name()
    huds[name] = nil
    update_hud(player)
    core.after(2, function()
        local live = core.get_player_by_name(name)
        if not live then return end
        remember_spawn(live:get_pos())
        local inventory = live:get_inventory()
        if inventory and not inventory:contains_item("main", "mw_core:guide") then
            inventory:add_item("main", "mw_core:guide")
        end
        core.chat_send_player(name, "[MURDIWORLD] Crystal Adventure loaded. Open your guide or type /mw.")
    end)
end)

core.register_on_leaveplayer(function(player)
    huds[player:get_player_name()] = nil
end)

core.register_on_player_receive_fields(function(player, formname, fields)
    if formname ~= "mw_core:guide" then return false end
    if fields.sethome then set_home(player) end
    if fields.home then teleport_to(player, core.string_to_pos(player:get_meta():get_string("mw_home"))) end
    if fields.hub then teleport_to(player, find_spawn()) end
    return true
end)

core.register_chatcommand("mw", {
    description = "Open the MURDIWORLD guide and crystal quest",
    func = function(name)
        local player = get_player(name)
        if not player then return false, "Player not online" end
        show_guide(player)
        return true, "Guide opened"
    end,
})

core.register_chatcommand("mwsethome", {
    description = "Save your home position",
    func = function(name)
        local player = get_player(name)
        if not player then return false, "Player not online" end
        return set_home(player)
    end,
})

core.register_chatcommand("mwhome", {
    description = "Teleport to your saved home",
    func = function(name)
        local player = get_player(name)
        if not player then return false, "Player not online" end
        return teleport_to(player, core.string_to_pos(player:get_meta():get_string("mw_home")))
    end,
})

core.register_chatcommand("mwhub", {
    description = "Return to the first arrival point",
    func = function(name)
        local player = get_player(name)
        if not player then return false, "Player not online" end
        return teleport_to(player, find_spawn())
    end,
})

core.log("action", "[mw_core] MURDIWORLD crystal quest enabled")
