﻿# MURDIWORLD prototype 0.1 - inspectable one-click Windows setup
# No administrator privileges required. Downloads pinned original binaries
# from official project release sources. Existing world is never deleted.
param(
    [ValidateSet('play','server','join','backup','verify')]
    [string]$Action = 'play'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Root = $PSScriptRoot
$LuantiVersion = '5.18.0'
$LuantiUrl = 'https://github.com/luanti-org/luanti/releases/download/5.18.0/luanti-5.18.0-win64.zip'
$LuantiSha256 = 'bebce52b58555d8208bf16767d0717788479fef23c35ec8d7bf287774d641835'
# ContentDB's numbered archive is immutable; this is VoxeLibre 0.92.4.
$VoxeLibreReleaseId = '39534'
$GameUrl = "https://content.luanti.org/packages/Wuzzy/mineclone2/releases/$VoxeLibreReleaseId/download/"
$Runtime = Join-Path $Root 'runtime'
$EngineDir = Join-Path $Runtime "luanti-$LuantiVersion"
$Exe = Join-Path $EngineDir 'bin\luanti.exe'
$GameDir = Join-Path $EngineDir 'games\mineclone2'
$WorldDir = Join-Path $Root 'save\murdiworld'
$BackupDir = Join-Path $Root 'backups'
$ConfigDir = Join-Path $Root 'config'

function Note([string] $Text) { Write-Host "[MURDIWORLD] $Text" -ForegroundColor Cyan }
function Ensure-Directory([string] $Path) { if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null } }
function Fetch-Archive([string] $Uri, [string] $Dest, [long] $MinSize, [long] $MaxSize) {
    Note 'Downloading original files over HTTPS. First launch needs Internet.'
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -UseBasicParsing -Uri $Uri -OutFile $Dest -MaximumRedirection 10 -TimeoutSec 600
    $size = (Get-Item -LiteralPath $Dest).Length
    if ($size -lt $MinSize -or $size -gt $MaxSize) { throw "Unexpected archive size: $size. Source: $Uri" }
}
function Check-SafeZip([string] $Archive) {
    Add-Type -AssemblyName System.IO.Compression -ErrorAction SilentlyContinue
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    $zip = [System.IO.Compression.ZipFile]::OpenRead($Archive)
    try {
        $total = [long]0
        foreach ($entry in $zip.Entries) {
            $entryPath = $entry.FullName.Replace('\','/')
            if ($entryPath.StartsWith('/') -or $entryPath -match '(^|/)\.\.(/|$)' -or $entryPath -match '^[A-Za-z]:') {
                throw "Archive path rejected: $entryPath"
            }
            $total += [long]$entry.Length
            if ($total -gt 1500MB) { throw 'Archive expands beyond the 1.5 GiB safety limit.' }
        }
    } finally { $zip.Dispose() }
}
function Install-Engine {
    if (Test-Path -LiteralPath $Exe) { Note "Using installed Luanti $LuantiVersion"; return }
    Ensure-Directory $Runtime
    $work = Join-Path $Runtime ('temp-engine-' + [guid]::NewGuid().ToString('N'))
    Ensure-Directory $work
    try {
        $zip = Join-Path $work 'luanti.zip'
        Fetch-Archive $LuantiUrl $zip 10000000 50000000
        $found = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($found -ne $LuantiSha256) { throw "Luanti SHA256 mismatch! Refusing to run unexpected binary. Found: $found" }
        Check-SafeZip $zip
        $extracted = Join-Path $work 'extract'
        Expand-Archive -LiteralPath $zip -DestinationPath $extracted -Force
        $candidates = @(Get-ChildItem -LiteralPath $extracted -Recurse -Filter 'luanti.exe' -File | Where-Object { $_.Directory.Name -eq 'bin' })
        if ($candidates.Count -ne 1) { throw 'Expected exactly one official bin/luanti.exe in the archive.' }
        $source = $candidates[0].Directory.Parent.FullName
        if (-not (Test-Path -LiteralPath (Join-Path $source 'builtin'))) { throw 'Incomplete Luanti portable archive: missing builtin/' }
        if (Test-Path -LiteralPath $EngineDir) { Remove-Item -LiteralPath $EngineDir -Recurse -Force }
        Move-Item -LiteralPath $source -Destination $EngineDir
        if (-not (Test-Path -LiteralPath $Exe)) { throw 'Luanti EXE missing after extraction.' }
        Note "Verified official Luanti $LuantiVersion (SHA256 OK)."
    } finally {
        if (Test-Path -LiteralPath $work) { Remove-Item -LiteralPath $work -Recurse -Force }
    }
}
function Install-Game {
    if (Test-Path -LiteralPath (Join-Path $GameDir 'game.conf')) { Note 'Using installed VoxeLibre 0.92.4'; return }
    Ensure-Directory $Runtime
    $work = Join-Path $Runtime ('temp-game-' + [guid]::NewGuid().ToString('N'))
    Ensure-Directory $work
    try {
        $zip = Join-Path $work 'voxelibre.zip'
        Fetch-Archive $GameUrl $zip 20000000 180000000
        Check-SafeZip $zip
        $extracted = Join-Path $work 'extract'
        Expand-Archive -LiteralPath $zip -DestinationPath $extracted -Force
        $candidates = @(Get-ChildItem -LiteralPath $extracted -Recurse -Filter 'game.conf' -File | Where-Object { Test-Path -LiteralPath (Join-Path $_.Directory.FullName 'mods') })
        if ($candidates.Count -ne 1) { throw 'Expected a single VoxeLibre game.conf and mods directory.' }
        $source = $candidates[0].Directory.FullName
        if (-not (Test-Path -LiteralPath (Join-Path $source 'LICENSE.txt'))) { throw 'VoxeLibre GPL license missing; refusing to package altered archive.' }
        $gameParent = Join-Path $EngineDir 'games'
        Ensure-Directory $gameParent
        if (Test-Path -LiteralPath $GameDir) { Remove-Item -LiteralPath $GameDir -Recurse -Force }
        Move-Item -LiteralPath $source -Destination $GameDir
        if (-not (Test-Path -LiteralPath (Join-Path $GameDir 'game.conf'))) { throw 'VoxeLibre install failed.' }
        Note 'Installed VoxeLibre from official ContentDB, original license and credits included.'
    } finally {
        if (Test-Path -LiteralPath $work) { Remove-Item -LiteralPath $work -Recurse -Force }
    }
}
function Prepare-World {
    $template = Join-Path $Root 'world-template'
    if (-not (Test-Path -LiteralPath (Join-Path $WorldDir 'world.mt'))) {
        Ensure-Directory (Split-Path -Parent $WorldDir)
        Copy-Item -LiteralPath $template -Destination $WorldDir -Recurse
        Note 'Created a fresh MURDIWORLD save. It will be kept across launches.'
    } else {
        # Only update the original MURDIWORLD mod. Never overwrite map/player databases.
        $modsDir = Join-Path $WorldDir 'worldmods'
        Ensure-Directory $modsDir
        $source = Join-Path $template 'worldmods\mw_core'
        $destination = Join-Path $modsDir 'mw_core'
        Ensure-Directory $destination
        Copy-Item -Path (Join-Path $source '*') -Destination $destination -Force -Recurse
        Note 'Loaded existing saved world; map and player progression preserved.'
    }
}
function Check-Prepared {
    if (-not (Test-Path -LiteralPath $Exe)) { throw "Luanti not installed: $Exe" }
    if (-not (Test-Path -LiteralPath (Join-Path $GameDir 'game.conf'))) { throw 'VoxeLibre game not installed' }
    if (-not (Test-Path -LiteralPath (Join-Path $GameDir 'LICENSE.txt'))) { throw 'Game license missing' }
    if (-not (Test-Path -LiteralPath (Join-Path $WorldDir 'world.mt'))) { throw 'Save world not created' }
    if (-not (Test-Path -LiteralPath (Join-Path $WorldDir 'worldmods\mw_core\init.lua'))) { throw 'MURDIWORLD mod not installed' }
    Note 'Checks passed: real engine, original game, license, saved world and MURDIWORLD quest.'
}
function Show-LanAddress {
    Note 'LAN server listening on UDP port 30000. For friends on the same Wi-Fi, use your IPv4 address:'
    try {
        $addresses = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop | Where-Object {
            $_.IPAddress -notmatch '^127\.' -and $_.IPAddress -notmatch '^169\.254\.' -and $_.AddressState -eq 'Preferred'
        } | Select-Object -ExpandProperty IPAddress)
        foreach ($address in $addresses) { Write-Host "    $address : 30000" -ForegroundColor Green }
    } catch {
        Write-Host 'Use ipconfig to see your local IPv4 address.'
    }
    Note 'Public Internet play needs explicit port forwarding (UDP 30000) or hosted server.'
    Note 'Keep this window open; close it with Ctrl+C to stop the server.'
}

try {
    Write-Host ''
    Write-Host '=========================================================' -ForegroundColor DarkCyan
    Write-Host '           MURDIWORLD 0.1 - CRYSTAL ADVENTURE            ' -ForegroundColor Cyan
    Write-Host '=========================================================' -ForegroundColor DarkCyan
    Write-Host ''
    if ($Action -eq 'backup') {
        if (-not (Test-Path -LiteralPath $WorldDir)) { throw 'No world save exists yet. Launch the game first.' }
        if (Get-Process -Name 'luanti' -ErrorAction SilentlyContinue) { throw 'Close Luanti and the multiplayer server before making a backup.' }
        Ensure-Directory $BackupDir
        $stamp = Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
        $target = Join-Path $BackupDir "murdiworld_$stamp.zip"
        Compress-Archive -LiteralPath $WorldDir -DestinationPath $target -CompressionLevel Optimal
        Note "Backup created: $target"
        exit 0
    }
    if ($Action -ne 'verify') {
        Install-Engine
        Install-Game
        Prepare-World
    }
    Check-Prepared
    if ($Action -eq 'verify') { exit 0 }
    $config = Join-Path $ConfigDir 'solo.conf'
    if ($Action -eq 'server') {
        $config = Join-Path $ConfigDir 'server.conf'
        Show-LanAddress
        & $Exe '--server' '--world' $WorldDir '--config' $config
    } elseif ($Action -eq 'join') {
        $address = Read-Host 'Server IPv4 or hostname (Enter = 127.0.0.1)'
        if ([string]::IsNullOrWhiteSpace($address)) { $address = '127.0.0.1' }
        if ($address -notmatch '^[A-Za-z0-9.\-:]{1,253}$') { throw 'Invalid server address.' }
        $name = Read-Host 'Player name (Latin letters, numbers, underscore)'
        if ($name -notmatch '^[A-Za-z][A-Za-z0-9_]{2,19}$') { throw 'Player name: 3-20 Latin letters/numbers, starting with a letter.' }
        Note "Launching Luanti client for $address`:30000. Enter your server password/registration in Luanti."
        & $Exe '--address' $address '--port' '30000' '--name' $name '--config' $config
    } else {
        Note 'Launching your singleplayer world. First entry may take a minute to generate terrain.'
        & $Exe '--go' '--world' $WorldDir '--config' $config
    }
    if ($LASTEXITCODE -ne 0) { throw "Luanti terminated with code $LASTEXITCODE. Check log under runtime/luanti-$LuantiVersion/" }
} catch {
    Write-Host ''
    Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'Your world save has NOT been intentionally removed. See README-RU.txt.' -ForegroundColor Yellow
    exit 1
}
