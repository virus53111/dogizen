@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if %ERRORLEVEL%==0 (py -3 MurdilimaxOrbit.py) else (python MurdilimaxOrbit.py)
pause
