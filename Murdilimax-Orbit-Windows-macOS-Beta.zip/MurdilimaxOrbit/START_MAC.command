#!/bin/bash
set -e
cd "$(dirname "$0")"
/usr/bin/env python3 MurdilimaxOrbit.py
