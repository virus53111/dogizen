#!/bin/bash
set -e
python3 -m pip install --upgrade camoufox
python3 -m camoufox fetch
