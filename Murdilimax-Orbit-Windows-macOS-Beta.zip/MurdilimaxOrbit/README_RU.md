# Murdilimax Orbit — Windows + macOS Beta

Это рабочая основа настольной программы, **не готовый коммерческий антидетект**. Телефоны запускаются как реальные Android Virtual Devices через Android Studio, управление экранами через scrcpy. Не скрывает факт Android-эмуляции и не гарантирует обход определений устройств.

## Windows 10/11
1. Установить Python 3.11+, **Android Studio** (SDK, Emulator, AVD), создать виртуальный Android в Device Manager.
2. Установить scrcpy из официального репозитория https://github.com/Genymobile/scrcpy/releases, указать путь в настройках Orbit.
3. Запустить `START_WINDOWS.bat`, выбрать AVD → «Запустить AVD» → «Обновить» → выбрать работающий emulator → «Открыть экран».
4. Окна Android открываются как отдельные окна: можно таскать за заголовок, растягивать за край. «Сетка» и «В ряд» автоматически расставляют scrcpy на экране.
5. Для Camoufox запустить `INSTALL_CAMOUFOX_WINDOWS.bat` (или вручную `py -m pip install camoufox` и `py -m camoufox fetch`).

## macOS (Intel / Apple Silicon)
1. Установить Python 3.11+ с Tkinter (например, python.org Python), Android Studio и создать AVD. **macOS не запускает Windows .exe**, используйте скрипт `.command`.
2. Установить [Homebrew](https://brew.sh/) и затем `brew install scrcpy`; для ADB, если его нет в PATH: `brew install --cask android-platform-tools`.
3. В Терминале в папке программы: `chmod +x START_MAC.command` и `./START_MAC.command`, либо `python3 MurdilimaxOrbit.py`.
4. В настройках указать SDK, если не обнаружен (`~/Library/Android/sdk`). Выбрать AVD, запустить и открыть scrcpy.
5. Окна можно перемещать/изменять вручную. Для кнопок «Сетка», «В ряд», «+/-» потребуется **Privacy & Security → Accessibility → разрешить Terminal / Python**; управление окнами через AppleScript — экспериментальное и ещё не протестировано на физическом Mac.
6. Camoufox: `python3 -m pip install camoufox`, затем `python3 -m camoufox fetch`. Профили хранятся в `~/Library/Application Support/MurdilimaxOrbit/browser_profiles`.

## Важные ограничения
- Не `.exe` и не `.dmg`: это Python-код для локального запуска, зависимости ставятся отдельно.
- Android-эмуляторы **не являются антидетектом**. Camoufox предоставляет отдельный browser fingerprint engine, но не гарантирует невидимость.
- Автораcстановка macOS через Accessibility — предварительная реализация, требует теста на Mac; отдельные окна scrcpy можно перемещать без неё.
- Android Studio, Android SDK, AVD, scrcpy, Camoufox распространяются независимо по их лицензиям; они не включены в архив.
- Запуск множества AVD требует значительной RAM/CPU. Chrome/Google Play зависит от образа AVD.
- Нет облачных эмуляторов, аккаунтов, подписок, платёжной интеграции и отдельной anti-detect-системы для Android.

## Проверка исходного кода
`python3 -m py_compile MurdilimaxOrbit.py` или `python3 MurdilimaxOrbit.py --check`.

Официальные источники: https://developer.android.com/studio/run/emulator • https://github.com/Genymobile/scrcpy • https://github.com/daijro/camoufox
