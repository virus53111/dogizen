@echo off
py -3 -m pip install --upgrade camoufox
py -3 -m camoufox fetch
pause
