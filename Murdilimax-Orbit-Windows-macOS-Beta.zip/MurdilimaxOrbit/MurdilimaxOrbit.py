"""Murdilimax Orbit Beta – Windows and macOS Android/scrcpy & Camoufox profile manager.

Local desktop controller. Requires external Android SDK, scrcpy and Camoufox.
Does not spoof an Android device or bypass anti-bot checks on Android.
"""
from __future__ import annotations

import json
import math
import os
import shutil
import subprocess
import sys
import threading
import time
import uuid
import webbrowser
from pathlib import Path
from urllib.parse import urlparse
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

APP_DIR = (Path(os.environ.get('APPDATA') or Path.home()) / 'MurdilimaxOrbit' if os.name == 'nt' else Path.home() / 'Library' / 'Application Support' / 'MurdilimaxOrbit' if sys.platform == 'darwin' else Path.home() / '.config' / 'MurdilimaxOrbit')
APP_DIR.mkdir(parents=True, exist_ok=True)
CFG_FILE = APP_DIR / 'settings.json'
PROFILE_ROOT = APP_DIR / 'browser_profiles'
PROFILE_ROOT.mkdir(exist_ok=True)
BG = '#090F20'
PANEL = '#141D31'
CARD = '#1D2940'
EDGE = '#2D3C58'
FG = '#F2F5FF'
MUTED = '#9CAEC8'
PURPLE = '#AC92FF'
GREEN = '#55E6AF'


def load_config():
    defaults = {'sdk': '', 'scrcpy': '', 'profiles': [], 'initial_url': 'https://example.org'}
    if CFG_FILE.exists():
        try:
            data = json.loads(CFG_FILE.read_text(encoding='utf-8'))
            if isinstance(data, dict):
                defaults.update(data)
        except (ValueError, OSError):
            pass
    if not isinstance(defaults.get('profiles'), list):
        defaults['profiles'] = []
    return defaults


def save_config(cfg):
    CFG_FILE.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding='utf-8')


def find_sdk(cfg):
    candidates = [cfg.get('sdk', ''), os.getenv('ANDROID_HOME', ''), os.getenv('ANDROID_SDK_ROOT', ''),
                  str(Path.home() / 'AppData/Local/Android/Sdk'), str(Path.home() / 'Library/Android/sdk'), str(Path.home() / 'Library/Android/Sdk')]
    for candidate in candidates:
        if candidate and (Path(candidate) / 'platform-tools' / ('adb.exe' if os.name == 'nt' else 'adb')).exists():
            return Path(candidate)
    return None


def find_executable(name, sdk=None, cfg=None):
    """Resolve platform-dependent SDK tools or a user-selected scrcpy binary."""
    bare = name.removesuffix('.exe')
    filename = bare + ('.exe' if os.name == 'nt' else '')
    if bare == 'scrcpy':
        options = [(cfg or {}).get('scrcpy', ''),
                   str(Path(__file__).resolve().parent / 'tools' / 'scrcpy' / filename)]
        if os.name == 'nt':
            options.append(str(Path.home() / 'Downloads/scrcpy-win64/scrcpy.exe'))
        else:
            options += ['/opt/homebrew/bin/scrcpy', '/usr/local/bin/scrcpy']
        for candidate in options:
            if candidate and Path(candidate).is_file():
                return str(Path(candidate))
    if sdk and bare in ('adb', 'emulator'):
        folder = 'platform-tools' if bare == 'adb' else 'emulator'
        exe = sdk / folder / filename
        if exe.is_file():
            return str(exe)
    return shutil.which(filename) or (shutil.which(bare) if bare != filename else None)


def run_capture(args, timeout=12):
    kwargs = {'capture_output': True, 'text': True, 'timeout': timeout, 'encoding': 'utf-8', 'errors': 'replace'}
    if os.name == 'nt':
        kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
    try:
        p = subprocess.run(args, **kwargs)
        return p.returncode, (p.stdout + '\n' + p.stderr).strip()
    except Exception as exc:
        return 1, str(exc)


def safe_start_url(text):
    text = (text or '').strip()
    if text.startswith(('https://', 'http://', 'about:')):
        return text
    if text and '.' in text and ' ' not in text:
        return 'https://' + text
    return 'https://example.org'


def validate_proxy(text):
    if not text:
        return None
    parsed = urlparse(text)
    if parsed.scheme not in ('http', 'https', 'socks5') or not parsed.hostname or not parsed.port:
        raise ValueError('Прокси: укажи http://host:port или socks5://host:port.')
    if parsed.username or parsed.password:
        raise ValueError('В этой версии не сохраняем пароль прокси. Используй IP-авторизацию.')
    return {'server': text}


def browser_worker(profile_id):
    """Separate process per Camoufox persistent profile."""
    cfg = load_config()
    profile = next((p for p in cfg['profiles'] if p.get('id') == profile_id), None)
    if not profile:
        print('Профиль не найден', file=sys.stderr)
        return 2
    try:
        from camoufox.sync_api import Camoufox
        proxy = validate_proxy(profile.get('proxy', ''))
        directory = PROFILE_ROOT / profile_id
        directory.mkdir(exist_ok=True)
        args = {'persistent_context': True, 'user_data_dir': str(directory), 'headless': False,
                'os': 'macos' if sys.platform == 'darwin' else 'windows', 'enable_cache': True}
        if proxy:
            args['proxy'] = proxy
        with Camoufox(**args) as context:
            page = context.pages[0] if context.pages else context.new_page()
            if page.url == 'about:blank':
                try:
                    page.goto(safe_start_url(profile.get('url')), timeout=20000)
                except Exception:
                    pass
            while True:
                try:
                    if not context.pages or all(p.is_closed() for p in context.pages):
                        break
                except Exception:
                    break
                time.sleep(0.5)
    except ImportError:
        print('Не установлен Camoufox. Установи pip install camoufox, затем camoufox fetch.', file=sys.stderr)
        return 3
    except Exception as exc:
        print(f'Ошибка Camoufox: {exc}', file=sys.stderr)
        return 4
    return 0


class WindowManager:
    """Controls only Windows whose title was set by this app for scrcpy."""
    PREFIX = 'Murdilimax Orbit Android | '

    @staticmethod
    def windows():
        if os.name != 'nt':
            return []
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        u.EnumWindows.argtypes = [ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM), wintypes.LPARAM]
        u.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        u.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        found = []
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        @callback_type
        def cb(hwnd, _):
            if not u.IsWindowVisible(hwnd):
                return True
            length = u.GetWindowTextLengthW(hwnd)
            if length < 1:
                return True
            buf = ctypes.create_unicode_buffer(length + 1)
            u.GetWindowTextW(hwnd, buf, length + 1)
            if buf.value.startswith(WindowManager.PREFIX):
                found.append(hwnd)
            return True
        u.EnumWindows(cb, 0)
        return found

    @staticmethod
    def layout(mode='grid', scale=1):
        if sys.platform == 'darwin':
            return WindowManager.layout_macos(mode, scale)
        if os.name != 'nt':
            return 0
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        rect = wintypes.RECT()
        u.SystemParametersInfoW(48, 0, ctypes.byref(rect), 0)  # SPI_GETWORKAREA
        work_w, work_h = rect.right - rect.left, rect.bottom - rect.top
        wins = WindowManager.windows()
        if not wins:
            return 0
        gap = 12
        n = len(wins)
        columns = n if mode == 'row' else max(1, math.ceil(math.sqrt(n * max(work_w, 1) / max(work_h, 1))))
        columns = min(columns, n)
        rows = math.ceil(n / columns)
        cw = max(220, int((work_w - gap * (columns + 1)) / columns))
        ch = max(320, int((work_h - gap * (rows + 1)) / rows))
        if mode == 'scale':
            for hwnd in wins:
                box = wintypes.RECT()
                u.GetWindowRect(hwnd, ctypes.byref(box))
                w = max(220, min(work_w, int((box.right - box.left) * scale)))
                h = max(330, min(work_h, int((box.bottom - box.top) * scale)))
                u.MoveWindow(hwnd, box.left, box.top, w, h, True)
        else:
            for i, hwnd in enumerate(wins):
                x = rect.left + gap + (i % columns) * (cw + gap)
                y = rect.top + gap + (i // columns) * (ch + gap)
                u.ShowWindow(hwnd, 9)  # SW_RESTORE
                u.MoveWindow(hwnd, x, y, cw, ch, True)
        return n


    @staticmethod
    def layout_macos(mode='grid', scale=1):
        """Arrange scrcpy windows on macOS using Accessibility AppleScript.

        macOS prompts for Accessibility permission for the host Terminal/Python app.
        This is best-effort. Windows remain manually draggable/resizable regardless.
        """
        import tkinter as tk
        screen=tk.Tk()
        screen.withdraw()
        screen_w,screen_h=screen.winfo_screenwidth(),screen.winfo_screenheight()
        screen.destroy()
        # Pass numeric arguments only; do not interpolate arbitrary AVD names into AppleScript.
        count_script="""tell application "System Events"
            if exists process "scrcpy" then
                tell process "scrcpy"
                    return count of windows
                end tell
            end if
            return 0
        end tell"""
        rc,output=run_capture(['osascript','-e',count_script],timeout=12)
        if rc:
            raise RuntimeError('Дай доступ Accessibility приложению Terminal/Python в настройках macOS. ' + output[:250])
        try: n=int(output.strip())
        except ValueError: n=0
        if n<1: return 0
        gap=12
        columns=n if mode=='row' else max(1,math.ceil(math.sqrt(n*screen_w/max(screen_h,1))))
        columns=min(columns,n)
        rows=math.ceil(n/columns)
        width=max(220,int((screen_w-gap*(columns+1))/columns))
        height=max(315,int((screen_h-66-gap*(rows+1))/rows))
        lines=['tell application "System Events"','tell process "scrcpy"']
        for i in range(1,n+1):
            if mode=='scale':
                # Avoid guessing existing dimensions: default desktop window size * factor.
                lines.append('set size of window '+str(i)+' to {'+str(max(220,int(355*scale)))+', '+str(max(330,int(630*scale)))+'}')
            else:
                x=gap+((i-1)%columns)*(width+gap)
                y=36+gap+((i-1)//columns)*(height+gap)
                lines += ['set position of window '+str(i)+' to {'+str(x)+', '+str(y)+'}',
                          'set size of window '+str(i)+' to {'+str(width)+', '+str(height)+'}']
        lines+=['end tell','end tell']
        status,message=run_capture(['osascript','-e','\n'.join(lines)],timeout=20)
        if status: raise RuntimeError('macOS не разрешил переставить окна: '+message[:250])
        return n


class PocketFleet:
    def __init__(self, root):
        self.root = root
        self.cfg = load_config()
        self.sdk = find_sdk(self.cfg)
        self.running = {}
        self.root.title('Murdilimax Orbit Studio · Windows / macOS Beta')
        self.root.geometry('1090x745')
        self.root.minsize(860, 610)
        self.root.configure(bg=BG)
        self.set_style()
        self.build_ui()
        self.refresh_all()

    def set_style(self):
        st = ttk.Style(self.root)
        st.theme_use('clam')
        st.configure('Treeview', background=PANEL, foreground=FG, fieldbackground=PANEL,
                     borderwidth=0, rowheight=42, font=('Helvetica Neue' if sys.platform == 'darwin' else 'Segoe UI', 10))
        st.map('Treeview', background=[('selected', '#3F376A')])
        st.configure('Treeview.Heading', background=CARD, foreground='#B4BED5',
                     borderwidth=0, padding=12, font=('Segoe UI Semibold', 9))
        st.configure('TScrollbar', background=EDGE, troughcolor=PANEL)
        st.configure('TCombobox', fieldbackground='#202C44')

    def label(self, master, text, size=10, color=FG, weight='normal', **kwargs):
        widget = tk.Label(master, text=text, bg=kwargs.pop('bg', master.cget('bg')),
                          fg=color, font=('Helvetica Neue' if sys.platform == 'darwin' else 'Segoe UI', size, weight), **kwargs)
        return widget

    def button(self, master, text, command, primary=False, width=None):
        opts = {'text': text, 'command': command, 'bg': '#9E83F5' if primary else CARD,
                'fg': '#140F29' if primary else '#E4E9FF', 'activebackground': '#BEA9FF' if primary else '#344467',
                'activeforeground': '#111126', 'relief': 'flat', 'bd': 0,
                'font': ('Helvetica Neue' if sys.platform == 'darwin' else 'Segoe UI Semibold', 10), 'padx': 13, 'pady': 10, 'cursor': 'hand2'}
        if width:
            opts['width'] = width
        return tk.Button(master, **opts)

    def build_ui(self):
        header = tk.Frame(self.root, bg=BG, height=74)
        header.pack(fill='x', padx=28, pady=(14, 0))
        self.label(header, '◈', size=31, color=PURPLE).pack(side='left', padx=(0, 12))
        top = tk.Frame(header, bg=BG)
        top.pack(side='left', pady=5)
        self.label(top, 'Murdilimax Orbit', size=19, weight='bold').pack(anchor='w')
        self.label(top, 'ANDROID + BROWSER STUDIO', size=8, color=MUTED).pack(anchor='w')
        self.status = tk.StringVar(value='Проверка компонентов…')
        self.label(header, '', size=9, color=GREEN, textvariable=self.status).pack(side='right', pady=20)

        nav = tk.Frame(self.root, bg=BG)
        nav.pack(fill='x', padx=28, pady=(12, 16))
        self.tabs = {}
        for key, title in [('android', '▯  Android-телефоны'), ('browser', '◉  Браузерные профили'),
                           ('setup', '⚙  Настройки')]:
            b = self.button(nav, title, lambda k=key: self.show_tab(k))
            b.pack(side='left', padx=(0, 10))
            self.tabs[key] = b
        self.button(nav, '↻ Обновить', self.refresh_all).pack(side='right')
        self.work = tk.Frame(self.root, bg=BG)
        self.work.pack(fill='both', expand=True, padx=28, pady=(0, 14))
        self.panels = {}
        self.panels['android'] = tk.Frame(self.work, bg=BG)
        self.panels['browser'] = tk.Frame(self.work, bg=BG)
        self.panels['setup'] = tk.Frame(self.work, bg=BG)
        self.make_android(self.panels['android'])
        self.make_browser(self.panels['browser'])
        self.make_setup(self.panels['setup'])
        self.show_tab('android')
        footer = tk.Frame(self.root, bg=BG)
        footer.pack(fill='x', padx=28, pady=(0, 15))
        self.label(footer, 'БЕТА: настоящие Android-экраны открываются в окнах scrcpy. Камуфляж Android не реализован.',
                   size=9, color='#7F8BA5').pack(side='left')

    def head(self, panel, title, desc):
        self.label(panel, title, size=21, weight='bold').pack(anchor='w', pady=(10, 3))
        self.label(panel, desc, size=10, color=MUTED, wraplength=920).pack(anchor='w', pady=(0, 17))

    def toolbar(self, panel):
        return tk.Frame(panel, bg=BG)

    def make_android(self, p):
        self.head(p, 'Android-телефоны', 'Подключённые Android устройства и установленные AVD. Каждый экран можно перетащить и изменить по размеру мышкой.')
        bar = self.toolbar(p)
        bar.pack(fill='x', pady=(0, 12))
        for title, cmd in [('▶ Запустить AVD', self.start_avd), ('▯ Открыть экран', self.show_android),
                           ('⊞ Сетка', lambda: self.arrange('grid')), ('☷ В ряд', lambda: self.arrange('row')),
                           ('−', lambda: self.arrange('scale', .8)), ('+', lambda: self.arrange('scale', 1.25))]:
            self.button(bar, title, cmd, primary=title.startswith('▯')).pack(side='left', padx=(0, 7))
        self.android_tree = ttk.Treeview(p, columns=('kind', 'state', 'note'), show='tree headings', selectmode='browse')
        self.android_tree.heading('#0', text='УСТРОЙСТВО / AVD')
        for k, t, w in [('kind', 'ТИП', 125), ('state', 'СТАТУС', 125), ('note', 'ИНФОРМАЦИЯ', 270)]:
            self.android_tree.heading(k, text=t)
            self.android_tree.column(k, width=w, stretch=(k=='note'))
        self.android_tree.column('#0', width=270)
        self.android_tree.pack(fill='both', expand=True)
        self.android_tree.bind('<Double-1>', lambda _: self.show_android())
        bar2 = self.toolbar(p)
        bar2.pack(fill='x', pady=(13, 0))
        for title, cmd in [('Установить APK', self.install_apk), ('Снимок экрана', self.screenshot),
                           ('Домой', lambda: self.adb_key('3')), ('Назад', lambda: self.adb_key('4')),
                           ('Перезагрузить', self.reboot_android)]:
            self.button(bar2, title, cmd).pack(side='left', padx=(0, 7))
        self.label(p, 'AVD запускается реальным Android Emulator. scrcpy показывает экран и передаёт касания/клавиатуру.',
                   size=9, color=MUTED).pack(anchor='w', pady=(16, 0))

    def make_browser(self, p):
        self.head(p, 'Браузерные профили', 'Изолированные профили Camoufox. Браузер запускается отдельным процессом, cookies хранятся локально.')
        bar = self.toolbar(p)
        bar.pack(fill='x', pady=(0, 12))
        for title, cmd in [('＋ Новый профиль', self.new_profile), ('▶ Запустить', self.launch_profile),
                           ('✎ Изменить', self.edit_profile), ('✕ Удалить', self.delete_profile)]:
            self.button(bar, title, cmd, primary=title.startswith('＋')).pack(side='left', padx=(0, 7))
        self.browser_tree = ttk.Treeview(p, columns=('url', 'proxy'), show='tree headings', selectmode='browse')
        self.browser_tree.heading('#0', text='НАЗВАНИЕ ПРОФИЛЯ')
        self.browser_tree.column('#0', width=300)
        self.browser_tree.heading('url', text='СТАРТОВАЯ СТРАНИЦА')
        self.browser_tree.column('url', width=350)
        self.browser_tree.heading('proxy', text='ПРОКСИ')
        self.browser_tree.column('proxy', width=250)
        self.browser_tree.pack(fill='both', expand=True)
        self.browser_tree.bind('<Double-1>', lambda _: self.launch_profile())
        help_box = tk.Frame(p, bg=PANEL, padx=17, pady=15)
        help_box.pack(fill='x', pady=17)
        self.label(help_box, '◈  Camoufox — отдельный движок с защитой отпечатка',
                   size=11, color=PURPLE, weight='bold').pack(anchor='w')
        self.label(help_box, 'Установка: python -m pip install camoufox, затем python -m camoufox fetch.\n'
                            'Функции и эффективность защиты определяются Camoufox; абсолютная невидимость не гарантируется.',
                   size=9, color=MUTED, justify='left').pack(anchor='w', pady=(8, 0))

    def make_setup(self, p):
        self.head(p, 'Настройки и компоненты', 'Укажи системные инструменты. Orbit сам не скачивает Android-образы.')
        self.paths = {}
        for key, text, value in [('sdk', 'Android SDK (корневая папка)', self.cfg.get('sdk', '')),
                                 ('scrcpy', 'Путь к scrcpy (исполняемый файл)', self.cfg.get('scrcpy', ''))]:
            box = tk.Frame(p, bg=PANEL, padx=17, pady=16)
            box.pack(fill='x', pady=(0, 13))
            self.label(box, text, color='#D4DBEE', size=10, weight='bold').pack(anchor='w')
            line = tk.Frame(box, bg=PANEL)
            line.pack(fill='x', pady=(8, 0))
            var = tk.StringVar(value=value)
            entry = tk.Entry(line, textvariable=var, relief='flat', font=('Helvetica Neue' if sys.platform == 'darwin' else 'Segoe UI', 11), bg='#25324B', fg=FG,
                             insertbackground='white', highlightthickness=0)
            entry.pack(side='left', fill='x', expand=True, ipady=9)
            self.button(line, 'Обзор', lambda k=key, v=var: self.browse(k, v)).pack(side='left', padx=(9, 0))
            self.paths[key] = var
        bar = self.toolbar(p)
        bar.pack(anchor='w', pady=10)
        self.button(bar, 'Сохранить', self.save_settings, primary=True).pack(side='left', padx=(0, 10))
        self.button(bar, 'Проверить инструменты', self.diagnostics).pack(side='left')
        self.label(p, 'Необходимо: Windows 10/11 или macOS, Python 3.11+, Android Studio/SDK, AVD, scrcpy.\n'
                      'Для Windows: WHPX и VT-x/AMD-V. Для macOS: доступная аппаратная виртуализация.\n'
                      'Можно подключать и настоящие Android-телефоны по USB с разрешённой отладкой.',
                   color=MUTED, size=10, justify='left').pack(anchor='w', pady=(25, 18))
        self.button(p, '↗ Android Studio', lambda: webbrowser.open('https://developer.android.com/studio')).pack(anchor='w', pady=5)
        self.button(p, '↗ scrcpy GitHub', lambda: webbrowser.open('https://github.com/Genymobile/scrcpy')).pack(anchor='w', pady=5)
        self.button(p, '↗ Camoufox', lambda: webbrowser.open('https://camoufox.com/')).pack(anchor='w', pady=5)

    def show_tab(self, tab):
        for name, frame in self.panels.items():
            frame.pack_forget()
            self.tabs[name].configure(bg=PURPLE if name == tab else CARD,
                                      fg=BG if name == tab else FG)
        self.panels[tab].pack(fill='both', expand=True)

    def selected_android(self):
        selection = self.android_tree.selection()
        return selection[0] if selection else None

    def selected_serial(self):
        selection = self.selected_android()
        if selection and selection.startswith('device:'):
            return selection.partition(':')[2]
        messagebox.showinfo('Выбери устройство', 'Выбери запущенный Android в списке. Для AVD сначала нажми «Запустить AVD».')
        return None

    def selected_profile(self):
        sel = self.browser_tree.selection()
        if not sel:
            messagebox.showinfo('Профиль', 'Сначала выбери профиль в списке.')
            return None
        return next((p for p in self.cfg['profiles'] if p.get('id') == sel[0]), None)

    def refresh_all(self):
        self.sdk = find_sdk(self.cfg)
        adb = find_executable('adb.exe', self.sdk)
        emu = find_executable('emulator.exe', self.sdk)
        scrcpy = find_executable('scrcpy.exe', self.sdk, self.cfg)
        self.status.set('● ADB ' + ('OK' if adb else 'НЕТ') + '  ·  SCRCPY ' + ('OK' if scrcpy else 'НЕТ'))
        self.android_tree.delete(*self.android_tree.get_children())
        if adb:
            rc, out = run_capture([adb, 'devices', '-l'])
            if rc == 0:
                for ln in out.splitlines()[1:]:
                    words = ln.split()
                    if len(words) >= 2:
                        serial, status = words[0], words[1]
                        if status in ('device', 'offline', 'unauthorized'):
                            self.android_tree.insert('', 'end', iid='device:'+serial, text=serial,
                                                     values=('Android / ADB', status, ' '.join(words[2:])[:50]))
        if emu:
            rc, out = run_capture([emu, '-list-avds'])
            if rc == 0:
                for name in out.splitlines():
                    name = name.strip()
                    if name and not name.startswith(('INFO', 'WARNING', 'ERROR')):
                        self.android_tree.insert('', 'end', iid='avd:'+name, text=name,
                                                 values=('Android AVD', 'Доступен', 'Можно запустить'))
        self.browser_tree.delete(*self.browser_tree.get_children())
        for p in self.cfg['profiles']:
            self.browser_tree.insert('', 'end', iid=p['id'], text=p['name'],
                                     values=(p.get('url', ''), p.get('proxy') or 'Прямое подключение'))

    def dispatch(self, fn):
        def worker():
            try:
                fn()
            except Exception as exc:
                self.root.after(0, lambda err=str(exc): messagebox.showerror('Ошибка', err))
        threading.Thread(target=worker, daemon=True).start()

    def start_avd(self):
        selected = self.selected_android()
        if not selected or not selected.startswith('avd:'):
            messagebox.showinfo('Запуск AVD', 'Выбери строку с типом Android AVD.')
            return
        emu = find_executable('emulator.exe', self.sdk)
        if not emu:
            messagebox.showerror('Нет эмулятора', 'Установи Android SDK Emulator в Android Studio.')
            return
        name = selected.partition(':')[2]
        if not messagebox.askyesno('Android', f'Запустить настоящий Android AVD «{name}»?\nЭто может потребовать несколько гигабайт памяти.'):
            return
        try:
            # Standard Android Emulator window; move it on Windows by dragging the native title bar.
            subprocess.Popen([emu, '-avd', name, '-no-boot-anim'],
                             creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
            self.status.set('● Запускается AVD: ' + name)
            self.root.after(9000, self.refresh_all)
        except Exception as exc:
            messagebox.showerror('Не удалось запустить AVD', str(exc))

    def show_android(self):
        serial = self.selected_serial()
        if not serial:
            return
        exe = find_executable('scrcpy.exe', self.sdk, self.cfg)
        if not exe:
            messagebox.showerror('scrcpy не найден', 'Скачай официальный scrcpy и укажи путь в настройках.')
            self.show_tab('setup')
            return
        try:
            p = subprocess.Popen([exe, '-s', serial, '--window-title=Murdilimax Orbit Android | ' + serial,
                                  '--window-width=355', '--window-height=620'],
                                 cwd=str(Path(exe).parent))
            self.running[serial] = p
            self.status.set('● Открыт Android-экран: ' + serial)
        except Exception as exc:
            messagebox.showerror('Запуск scrcpy', str(exc))

    def arrange(self, mode, scale=1):
        try:
            count = WindowManager.layout(mode, scale)
        except Exception as e:
            messagebox.showwarning('Управление окнами', str(e))
            return
        if count < 1:
            messagebox.showinfo('Экраны', 'Открой экраны Android через кнопку «Открыть экран».\nЗатем используй сетку, ряд или масштаб.')
        else:
            self.status.set(f'● Расположено экранов Android: {count}')

    def adb_action(self, args, serial=None, timeout=50, finished=None):
        adb = find_executable('adb.exe', self.sdk)
        if not adb:
            messagebox.showerror('ADB', 'ADB отсутствует. Установи Android SDK.')
            return
        serial = serial or self.selected_serial()
        if not serial:
            return
        def work():
            rc, out = run_capture([adb, '-s', serial] + args, timeout=timeout)
            self.root.after(0, lambda: (messagebox.showinfo('Android', finished or 'Успешно') if rc == 0
                                        else messagebox.showerror('Android', out[:1200])))
        self.dispatch(work)

    def install_apk(self):
        serial = self.selected_serial()
        if not serial:
            return
        file = filedialog.askopenfilename(title='Установить APK', filetypes=[('Android Package', '*.apk')])
        if file:
            self.adb_action(['install', '-r', file], serial, timeout=240, finished='APK установлен на Android.')

    def screenshot(self):
        serial = self.selected_serial()
        if not serial:
            return
        target = filedialog.asksaveasfilename(title='Сохранить снимок экрана', defaultextension='.png',
                                              filetypes=[('PNG image', '*.png')], initialfile='android-screen.png')
        if not target:
            return
        adb = find_executable('adb.exe', self.sdk)
        def work():
            try:
                p = subprocess.run([adb, '-s', serial, 'exec-out', 'screencap', '-p'],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
                if p.returncode:
                    raise RuntimeError(p.stderr.decode('utf-8', errors='replace'))
                Path(target).write_bytes(p.stdout)
                self.root.after(0, lambda: messagebox.showinfo('Готово', 'Снимок сохранён.'))
            except Exception as e:
                self.root.after(0, lambda err=str(e): messagebox.showerror('Снимок', err))
        self.dispatch(work)

    def adb_key(self, code):
        self.adb_action(['shell', 'input', 'keyevent', code], timeout=12, finished='Команда передана Android.')

    def reboot_android(self):
        serial = self.selected_serial()
        if serial and messagebox.askyesno('Перезагрузка', f'Перезагрузить {serial}?'):
            self.adb_action(['reboot'], serial, timeout=15, finished='Устройство перезагружается.')

    def profile_dialog(self, existing=None):
        win = tk.Toplevel(self.root)
        win.title('Браузерный профиль')
        win.configure(bg=PANEL)
        win.geometry('455x360')
        win.resizable(False, False)
        win.transient(self.root)
        win.grab_set()
        values = {}
        for label, key, default in [('Название профиля', 'name', existing.get('name', '') if existing else ''),
                                    ('Стартовый URL', 'url', existing.get('url', 'https://example.org') if existing else 'https://example.org'),
                                    ('Прокси: http://host:port (опционально)', 'proxy', existing.get('proxy', '') if existing else '')]:
            self.label(win, label, size=10).pack(anchor='w', padx=25, pady=(16, 3))
            var = tk.StringVar(value=default)
            entry = tk.Entry(win, textvariable=var, bg='#28334D', fg=FG, insertbackground='white', relief='flat',
                             font=('Helvetica Neue' if sys.platform == 'darwin' else 'Segoe UI', 11))
            entry.pack(fill='x', padx=25, ipady=9)
            values[key] = var
        self.label(win, 'Сессии и cookies сохраняются в профиле на вашем ПК.', color=MUTED, size=9).pack(anchor='w', padx=25, pady=12)
        def submit():
            name = values['name'].get().strip()
            proxy = values['proxy'].get().strip()
            if not name:
                messagebox.showerror('Ошибка', 'Введи название профиля.', parent=win)
                return
            try:
                validate_proxy(proxy)
            except ValueError as exc:
                messagebox.showerror('Ошибка прокси', str(exc), parent=win)
                return
            data = {'id': existing['id'] if existing else uuid.uuid4().hex[:16], 'name': name[:80],
                    'url': safe_start_url(values['url'].get()), 'proxy': proxy}
            if existing:
                existing.update(data)
            else:
                self.cfg['profiles'].append(data)
            save_config(self.cfg)
            self.refresh_all()
            win.destroy()
        self.button(win, 'Сохранить профиль', submit, primary=True).pack(padx=25, pady=7, anchor='e')
        self.root.wait_window(win)

    def new_profile(self):
        self.profile_dialog()

    def edit_profile(self):
        p = self.selected_profile()
        if p:
            self.profile_dialog(p)

    def delete_profile(self):
        p = self.selected_profile()
        if p and messagebox.askyesno('Удаление', 'Удалить профиль и локальные cookies?'):
            self.cfg['profiles'] = [x for x in self.cfg['profiles'] if x['id'] != p['id']]
            save_config(self.cfg)
            try:
                shutil.rmtree(PROFILE_ROOT / p['id'])
            except OSError:
                pass
            self.refresh_all()

    def launch_profile(self):
        p = self.selected_profile()
        if not p:
            return
        args = [sys.executable, str(Path(__file__).resolve()), '--camoufox-worker', p['id']]
        try:
            if getattr(sys, 'frozen', False):
                args = [sys.executable, '--camoufox-worker', p['id']]
            flags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
            subprocess.Popen(args, cwd=str(Path(__file__).resolve().parent), creationflags=flags)
            self.status.set('● Запуск Camoufox: ' + p['name'])
        except Exception as exc:
            messagebox.showerror('Camoufox', str(exc))

    def browse(self, kind, variable):
        if kind == 'sdk':
            selection = filedialog.askdirectory(title='Выбери папку Android SDK')
        else:
            selection = filedialog.askopenfilename(title='Выбери scrcpy', filetypes=[('Executable', '*.exe')] if os.name == 'nt' else [('All files', '*')])
        if selection:
            variable.set(selection)

    def save_settings(self):
        self.cfg['sdk'] = self.paths['sdk'].get().strip()
        self.cfg['scrcpy'] = self.paths['scrcpy'].get().strip()
        save_config(self.cfg)
        self.refresh_all()
        messagebox.showinfo('Murdilimax Orbit', 'Настройки сохранены.')

    def diagnostics(self):
        self.save_settings()
        sdk = find_sdk(self.cfg)
        adb = find_executable('adb.exe', sdk)
        emu = find_executable('emulator.exe', sdk)
        scrcpy = find_executable('scrcpy.exe', sdk, self.cfg)
        try:
            import importlib.util
            cam = bool(importlib.util.find_spec('camoufox'))
        except Exception:
            cam = False
        messagebox.showinfo('Диагностика', '\n'.join([
            'Android SDK: ' + (str(sdk) if sdk else 'НЕ НАЙДЕН'),
            'ADB: ' + ('OK' if adb else 'НЕ НАЙДЕН'),
            'Android Emulator: ' + ('OK' if emu else 'НЕ НАЙДЕН'),
            'scrcpy: ' + ('OK' if scrcpy else 'НЕ НАЙДЕН'),
            'Camoufox Python: ' + ('OK' if cam else 'НЕ УСТАНОВЛЕН'),
            '', 'Образы Android (AVD) устанавливаются отдельно через Android Studio.'
        ]))


def main():
    if len(sys.argv) == 3 and sys.argv[1] == '--camoufox-worker':
        raise SystemExit(browser_worker(sys.argv[2]))
    if '--check' in sys.argv:
        print('Murdilimax Orbit source check OK for',sys.platform)
        return
    root = tk.Tk()
    PocketFleet(root)
    root.mainloop()


if __name__ == '__main__':
    main()
